package com.example.studentsList;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsListApplicationTests {

	@Test
	void contextLoads() {
	}

}
